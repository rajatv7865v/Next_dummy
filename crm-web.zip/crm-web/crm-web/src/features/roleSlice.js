

import { createSlice } from '@reduxjs/toolkit'

const initialState = {
  value: '',
}

export const roleSclice = createSlice({
  name: 'role',
  initialState,
  reducers: {
 
  
    roleToggle: (state, action) => {
        console.log(action.payload)
      state.value = action.payload
      
    },
  },
})

// Action creators are generated for each case reducer function
export const {roleToggle } = roleSclice.actions

export default roleSclice.reducer