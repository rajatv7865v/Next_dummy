
import { configureStore } from '@reduxjs/toolkit'
import { roleSclice } from './features/roleSlice'
// import { roleSclice } from './features/roleSlice'
export const store = configureStore({
  reducer: {
    role:roleSclice
  },
})