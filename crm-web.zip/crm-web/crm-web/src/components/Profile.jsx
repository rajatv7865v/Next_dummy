import profileImage from '../assets/images/profile.png'
const Profile = () => {
  return (

    <div className=' flex flex-col items-center space-y-4'>
    <div className='w-36 h-36'>
    <img src={profileImage} alt="profile-image" />
     <div>
        <h1 className='font-medium text-xs md:text-sm text-center text-teal-500'>Akash Raja</h1>
      
     </div>
     <div className=' mfont-semibold text-lg text-center text-green-400 hover:cursor-zoom-in'>
        007658
     </div>
    </div>
    </div>
  )
}

export default Profile