import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

const AdminProtectedRoutes = (props) => {
  const navigate = useNavigate();
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const checkUserToken = () => {
    const role = sessionStorage.getItem("role");

    if (role && role === "user") {
      setIsLoggedIn(false);
      return navigate("/user/login");
    }
    setIsLoggedIn(true);
  };
  useEffect(() => {
    checkUserToken();
  }, [isLoggedIn]);

  return <>{isLoggedIn ? props.children : null}</>;
};

export default AdminProtectedRoutes;
